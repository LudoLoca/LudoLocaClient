// Configura��o principal do projeto cliente MVC (.NET 8)
// Este arquivo define todos os servi�os essenciais, middlewares e integra��es necess�rias para o funcionamento do frontend.

var builder = WebApplication.CreateBuilder(args);

// Adiciona suporte a controllers e views (MVC padr�o)
builder.Services.AddControllersWithViews();

// Configura��o de sess�o em mem�ria (apenas para desenvolvimento)
// Permite uso de TempData, autentica��o baseada em sess�o, etc.
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(30); // Tempo de expira��o da sess�o
    options.Cookie.HttpOnly = true;                 // Cookie n�o acess�vel via JS
    options.Cookie.IsEssential = true;              // Necess�rio para funcionamento do app
});

// Permite acesso ao HttpContext em views e layouts (ex: autentica��o, sess�o)
builder.Services.AddHttpContextAccessor();

// Configura��o do HttpClient para chamadas � API
// Usa o valor de ApiBaseUrl definido no appsettings.json ou vari�veis de ambiente
builder.Services.AddHttpClient("Api", client =>
{
    // ATEN��O: Certifique-se de que "ApiBaseUrl" est� definido corretamente no appsettings.json
    client.BaseAddress = new Uri(builder.Configuration["ApiBaseUrl"]!);
    // TODO: Adicionar tratamento para caso ApiBaseUrl n�o esteja definido
});

// Configura��o de autentica��o baseada em cookie para o MVC (n�o utiliza banco de dados ou JWT)
// Apenas para proteger rotas do lado do cliente, n�o interfere na autentica��o da API
builder.Services.AddAuthentication("AppCookie")
    .AddCookie("AppCookie", o =>
    {
        o.LoginPath = "/Account/Login";
        o.LogoutPath = "/Account/Logout";
        o.AccessDeniedPath = "/Account/AccessDenied";
        o.Cookie.HttpOnly = true;
        o.Cookie.SecurePolicy = CookieSecurePolicy.Always;
        o.SlidingExpiration = true;
    });

// Adiciona suporte a autoriza��o (usado com [Authorize] em controllers)
builder.Services.AddAuthorization();

var app = builder.Build();

// Configura��o de tratamento de erros e HSTS para produ��o
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

// Redireciona HTTP para HTTPS
app.UseHttpsRedirection();

// Habilita arquivos est�ticos (wwwroot, css, js, imagens)
app.UseStaticFiles();

// Define o roteamento padr�o do MVC
app.UseRouting();

// Habilita sess�o (deve vir antes de autentica��o/autoriza��o)
app.UseSession();

// Habilita autentica��o baseada em cookie
app.UseAuthentication();

// Habilita autoriza��o ([Authorize] em controllers)
app.UseAuthorization();

// Define a rota padr�o: Home/Index/{id?}
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();

//debug
